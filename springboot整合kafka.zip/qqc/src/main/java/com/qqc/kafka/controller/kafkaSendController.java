package com.qqc.kafka.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/kafka")
public class kafkaSendController {
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@RequestMapping(value = "/send", method = RequestMethod.GET)
	@ResponseBody
	public Object sendKafka(@RequestParam(value = "message", required = false) String message) {
		try {
			logger.info("kafka的消息={}", message);
			kafkaTemplate.send("test", "key", message);
			logger.info("发送kafka成功.");
			return "发送kafka成功";
		} catch (Exception e) {
			logger.error("发送kafka失败", e);
			return "发送kafka失败";
		}
	}
	
}
