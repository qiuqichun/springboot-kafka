package com.qqc.kafka.service;

public interface UserService {
	
	
	public Integer queryCount();
	
}
