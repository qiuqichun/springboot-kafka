package	com.qqc.kafka.config.dataSource;

import javax.sql.DataSource;

import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.qqc.kafka.config.DsConfig;
import com.qqc.kafka.config.PageHelperConfig;


/**
 * 
 * Oracle数据源配置
 * 
 * @author huangbijin
 * @date 2018/06/06
 */

@Configuration
@MapperScan(basePackages = "com.qqc.kafka.mapper.qqc",sqlSessionTemplateRef = DsConfig.QQC+"SqlSessionTemplate")
public class DataSourceConfigQQC{

  private final Logger logger = Logger.getLogger(DataSourceConfigQQC.class);
  
  	
    @Bean(name =DsConfig.QQC+"SqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier(DsConfig.QQC+"DataSource")DataSource dataSource)throws Exception {
        logger.info("setSqlSessionFactory()...");
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        bean.setMapperLocations( new PathMatchingResourcePatternResolver().getResources("classpath:mapping/"+ DsConfig.QQC + "/*.xml"));
        // 添加插件
        bean.setPlugins(new Interceptor[] {PageHelperConfig.pageHelper()});
        return bean.getObject();
    }

    @Bean(name =DsConfig.QQC+"TransactionManager")
    public DataSourceTransactionManager setTransactionManager(@Qualifier(DsConfig.QQC+"DataSource")DataSource dataSource) {
        logger.info("setTransactionManager()...");
      return new DataSourceTransactionManager(dataSource);
    }

   

   @Bean( DsConfig.QQC+"SqlSessionTemplate")
    public SqlSessionTemplate setSqlSessionTemplate(@Qualifier(DsConfig.QQC+"SqlSessionFactory")SqlSessionFactory sqlSessionFactory) throws Exception {
        logger.info("setSqlSessionTemplate()...");
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    
  /*@Bean(name = "jdbcTemplate")
    public JdbcTemplate setJdbcTemplate(@Qualifier("dataSource") DataSource dataSource) {
        logger.info("setJdbcTemplate()...");
        return new JdbcTemplate(dataSource);
    }*/

}
