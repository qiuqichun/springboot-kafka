package com.qqc.kafka.config;

import com.github.pagehelper.PageHelper;
import org.apache.ibatis.plugin.Interceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;

import java.util.Properties;

/**
 * 翻页插件配置
 * @author huangbijin
 * @date 2018/06/06
 */
public class PageHelperConfig {
    private static final Logger log = LoggerFactory.getLogger(PageHelperConfig.class);
    
    /**
     * MyBatis分页插件PageHelper
     * @return
     */
    @Bean
    public static Interceptor pageHelper(){
        log.info("MyBatis分页插件PageHelper");
        //分页插件
        PageHelper pageHelper = new PageHelper();
        Properties properties = new Properties();
        properties.setProperty("offsetAsPageNum", "true");
        properties.setProperty("rowBoundsWithCount", "true");
        properties.setProperty("reasonable", "true");
        properties.setProperty("supportMethodsArguments", "true");
        properties.setProperty("returnPageInfo", "check");
        properties.setProperty("params", "count=countSql");
        properties.setProperty("dialect", "oracle");
        pageHelper.setProperties(properties);
        Interceptor interceptor =  pageHelper;
        return interceptor;
    }
}
