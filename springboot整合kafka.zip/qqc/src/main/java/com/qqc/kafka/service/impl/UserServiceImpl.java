package com.qqc.kafka.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qqc.kafka.mapper.sqlserver.UserMapper;
import com.qqc.kafka.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	public UserMapper userMapper;
	

	@Override
	public Integer queryCount() {
		
		return this.userMapper.queryCounts();
	}
	
	
	

}
