--初始化管理员账号
insert into fmbi_user (mail_box_account_id) values ('fmbiAdmin');
--初始化管理员角色
insert into FMBI_ROLE_INFO (role_id, role_name, role_desc, role_type, create_time) values ('1', '管理员', '管理员专用', 0, to_timestamp('20-07-2018 09:00:52.000000', 'dd-mm-yyyy hh24:mi:ss.ff'));
--初始化管理员角色 
insert into fmbi_user_role (user_id,role_id) values ('fmbiAdmin','1');
--初始化管理数据权限
insert into fmbi_user_permission (mail_box_account_id,permission_route) values ('fmbiAdmin','0');
-- 初始化菜单
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (1,'系统管理',0,1,null,1,1,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (2,'菜单管理',1,1,'/menu/index',1,2,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (3,'角色管理',1,2,'/role/index',1,2,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (4,'Redis监控',1,3,'/redis/monitor',1,2,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (5,'授权',3,1,'/role/add',2,3,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (6,'主题报表',0,2,null,1,1,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (7,'报表管理',6,1,'/theme/index',1,2,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (8,'报表下载',6,1,'/progress/index',1,2,1);
Insert into DDS.FMBI_AUTHORITY (ID,NAME,PARENT_ID,SEQUENCE,DATA_URL,MENU_TYPE,MENU_LEVES,STATUS) values (9,'用户授权',1,5,'/userInfo/index',1,2,1);

--初始化权限 
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',1,1);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',2,1);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',3,1);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',4,1);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',5,2);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',6,1);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',7,1);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',8,1);
Insert into DDS.FMBI_ROLE_AUTHORITY (ROLE_ID,MENU_ID,MENU_TYPE) values ('1',9,1);

