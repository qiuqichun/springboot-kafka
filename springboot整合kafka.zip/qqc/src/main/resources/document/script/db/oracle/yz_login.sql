DROP TABLE yz_login;
CREATE TABLE yz_login 
(
  id VARCHAR(100) NOT NULL 
, name VARCHAR(200) NOT NULL 
, openId VARCHAR(200)	NOT NULL 
, createTime VARCHAR(50)
, updateTime VARCHAR(50)
, CONSTRAINT yz_login_KEY PRIMARY KEY 
  (
    openId 
  )

  ,CONSTRAINT yz_login_id UNIQUE (id)
);


